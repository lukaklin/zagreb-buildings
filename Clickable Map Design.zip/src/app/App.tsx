import { useState, useMemo } from "react";
import { MapComponent } from "./components/MapComponent";
import { SearchFilterBar, FilterOptions } from "./components/SearchFilterBar";
import { BuildingPanel } from "./components/BuildingPanel";
import { buildings as allBuildings, Building } from "./data/buildings";

export default function App() {
  const [selectedBuilding, setSelectedBuilding] = useState<Building | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState<FilterOptions>({
    architects: [],
    styles: [],
    yearRange: [1800, 2026]
  });

  // Filter and search buildings
  const filteredBuildings = useMemo(() => {
    return allBuildings.filter((building) => {
      // Search filter
      const matchesSearch = searchQuery === "" || 
        building.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        building.architect.toLowerCase().includes(searchQuery.toLowerCase()) ||
        building.style.toLowerCase().includes(searchQuery.toLowerCase());

      // Architect filter
      const matchesArchitect = filters.architects.length === 0 || 
        filters.architects.includes(building.architect);

      // Style filter
      const matchesStyle = filters.styles.length === 0 || 
        filters.styles.includes(building.style);

      // Year range filter
      const matchesYearRange = building.yearBuilt >= filters.yearRange[0] && 
        building.yearBuilt <= filters.yearRange[1];

      return matchesSearch && matchesArchitect && matchesStyle && matchesYearRange;
    });
  }, [searchQuery, filters]);

  const handleBuildingSelect = (building: Building) => {
    setSelectedBuilding(building);
  };

  const handleClosePanel = () => {
    setSelectedBuilding(null);
  };

  return (
    <div className="relative size-full">
      <MapComponent
        buildings={filteredBuildings}
        selectedBuilding={selectedBuilding}
        onBuildingSelect={handleBuildingSelect}
      />
      
      <SearchFilterBar
        onSearch={setSearchQuery}
        onFilter={setFilters}
        activeFilters={filters}
      />

      <BuildingPanel
        building={selectedBuilding}
        onClose={handleClosePanel}
      />
    </div>
  );
}
