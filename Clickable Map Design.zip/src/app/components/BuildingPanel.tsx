import { X, Calendar, User, Ruler, Package, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import { Building } from "../data/buildings";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ScrollArea } from "./ui/scroll-area";
import { Badge } from "./ui/badge";
import { motion, AnimatePresence } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface BuildingPanelProps {
  building: Building | null;
  onClose: () => void;
}

const imageMap: Record<string, string> = {
  "neo gothic cathedral twin spires": "https://images.unsplash.com/photo-1769615334885-2b9c168acd34?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZW8lMjBnb3RoaWMlMjBjYXRoZWRyYWwlMjB0d2luJTIwc3BpcmVzfGVufDF8fHx8MTc3MTA2NTUzOXww&ixlib=rb-4.1.0&q=80&w=1080",
  "neo baroque theatre building yellow": "https://images.unsplash.com/photo-1587396704200-10d9701d01f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZW8lMjBiYXJvcXVlJTIwdGhlYXRyZSUyMGJ1aWxkaW5nJTIweWVsbG93fGVufDF8fHx8MTc3MTA2NTUzOXww&ixlib=rb-4.1.0&q=80&w=1080",
  "modernist tower building": "https://images.unsplash.com/photo-1614447413603-4a001863d943?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm5pc3QlMjB0b3dlciUyMGJ1aWxkaW5nfGVufDF8fHx8MTc3MTA2NTUzOXww&ixlib=rb-4.1.0&q=80&w=1080",
  "art nouveau pavilion yellow": "https://images.unsplash.com/photo-1557949712-7b90a6130b72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnQlMjBub3V2ZWF1JTIwcGF2aWxpb24lMjB5ZWxsb3d8ZW58MXx8fHwxNzcxMDY1NTM5fDA&ixlib=rb-4.1.0&q=80&w=1080",
  "medieval stone tower": "https://images.unsplash.com/photo-1753869285821-7801f1b4d252?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpZXZhbCUyMHN0b25lJTIwdG93ZXJ8ZW58MXx8fHwxNzcxMDY1NTQwfDA&ixlib=rb-4.1.0&q=80&w=1080",
  "contemporary museum glass building": "https://images.unsplash.com/photo-1655908692769-018730fe7c06?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb250ZW1wb3JhcnklMjBtdXNldW0lMjBnbGFzcyUyMGJ1aWxkaW5nfGVufDF8fHx8MTc3MTA2NTU0MHww&ixlib=rb-4.1.0&q=80&w=1080",
  "art deco hotel building": "https://images.unsplash.com/photo-1507579827759-e45b4f9a9a27?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnQlMjBkZWNvJTIwaG90ZWwlMjBidWlsZGluZ3xlbnwxfHx8fDE3NzEwNjU1NDB8MA&ixlib=rb-4.1.0&q=80&w=1080",
  "brutalist concert hall": "https://images.unsplash.com/photo-1769283991436-9ce2354aaaf5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicnV0YWxpc3QlMjBjb25jcmV0ZSUyMGFyY2hpdGVjdHVyZXxlbnwxfHx8fDE3NzEwNjU1NDR8MA&ixlib=rb-4.1.0&q=80&w=1080",
  "neo renaissance palace building": "https://images.unsplash.com/photo-1716740165214-d01b0e4e0a51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZW8lMjByZW5haXNzYW5jZSUyMHBhbGFjZSUyMGJ1aWxkaW5nfGVufDF8fHx8MTc3MTA2NTU0MHww&ixlib=rb-4.1.0&q=80&w=1080",
  "neo renaissance museum building": "https://images.unsplash.com/photo-1647798542061-c513595d1908?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZW8lMjByZW5haXNzYW5jZSUyMG11c2V1bSUyMGJ1aWxkaW5nfGVufDF8fHx8MTc3MTA2NTU0MXww&ixlib=rb-4.1.0&q=80&w=1080",
};

function GalleryCarousel({ images }: { images: string[] }) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  return (
    <div className="relative">
      <div className="relative h-64 bg-gray-100 rounded-lg overflow-hidden">
        <ImageWithFallback
          src={`https://images.unsplash.com/photo-${Date.now() + currentIndex}?w=800&h=600&fit=crop`}
          alt={`Gallery image ${currentIndex + 1}`}
          className="size-full object-cover"
        />
      </div>
      
      {images.length > 1 && (
        <>
          <Button
            variant="outline"
            size="icon"
            className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white"
            onClick={goToPrevious}
          >
            <ChevronLeft className="size-4" />
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white"
            onClick={goToNext}
          >
            <ChevronRight className="size-4" />
          </Button>

          <div className="flex justify-center gap-2 mt-4">
            {images.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`size-2 rounded-full transition-colors ${
                  index === currentIndex ? "bg-black" : "bg-gray-300"
                }`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export function BuildingPanel({ building, onClose }: BuildingPanelProps) {
  return (
    <AnimatePresence>
      {building && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/30 z-[1001]"
          />

          {/* Panel */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed right-0 top-0 h-screen w-full md:w-[480px] bg-white shadow-2xl z-[1002] overflow-hidden"
          >
            <ScrollArea className="h-full">
              {/* Hero Image */}
              <div className="relative h-64 w-full">
                <img
                  src={imageMap[building.mainImage]}
                  alt={building.name}
                  className="size-full object-cover"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="absolute top-4 right-4 bg-white/90 hover:bg-white"
                >
                  <X className="size-4" />
                </Button>
              </div>

              {/* Content */}
              <div className="p-6 space-y-6">
                {/* Header */}
                <div>
                  <h2 className="text-2xl mb-2">{building.name}</h2>
                  <Badge variant="secondary">{building.style}</Badge>
                </div>

                {/* Quick Facts Grid */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                    <Calendar className="size-5 text-gray-600 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-600">Year Built</p>
                      <p className="font-medium">{building.yearBuilt}</p>
                      <p className="text-xs text-gray-500">{building.age} years old</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                    <User className="size-5 text-gray-600 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-600">Architect</p>
                      <p className="font-medium">{building.architect}</p>
                    </div>
                  </div>

                  {building.height && (
                    <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                      <Ruler className="size-5 text-gray-600 mt-0.5" />
                      <div>
                        <p className="text-xs text-gray-600">Height</p>
                        <p className="font-medium">{building.height}</p>
                      </div>
                    </div>
                  )}

                  {building.materials && building.materials.length > 0 && (
                    <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                      <Package className="size-5 text-gray-600 mt-0.5" />
                      <div>
                        <p className="text-xs text-gray-600">Materials</p>
                        <p className="font-medium text-sm">{building.materials[0]}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Tabs */}
                <Tabs defaultValue="overview" className="w-full">
                  <TabsList className="w-full">
                    <TabsTrigger value="overview" className="flex-1">Overview</TabsTrigger>
                    <TabsTrigger value="gallery" className="flex-1">Gallery</TabsTrigger>
                    <TabsTrigger value="details" className="flex-1">Details</TabsTrigger>
                  </TabsList>

                  <TabsContent value="overview" className="space-y-4 mt-4">
                    <div>
                      <h3 className="text-sm font-medium mb-2">Description</h3>
                      <p className="text-sm text-gray-600 leading-relaxed">
                        {building.description}
                      </p>
                    </div>
                  </TabsContent>

                  <TabsContent value="gallery" className="mt-4">
                    <GalleryCarousel images={building.gallery} />
                  </TabsContent>

                  <TabsContent value="details" className="space-y-4 mt-4">
                    <div className="space-y-3">
                      <div className="flex justify-between py-2 border-b">
                        <span className="text-sm text-gray-600">Building Name</span>
                        <span className="text-sm font-medium">{building.name}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b">
                        <span className="text-sm text-gray-600">Architect</span>
                        <span className="text-sm font-medium">{building.architect}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b">
                        <span className="text-sm text-gray-600">Year Built</span>
                        <span className="text-sm font-medium">{building.yearBuilt}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b">
                        <span className="text-sm text-gray-600">Age</span>
                        <span className="text-sm font-medium">{building.age} years</span>
                      </div>
                      <div className="flex justify-between py-2 border-b">
                        <span className="text-sm text-gray-600">Style</span>
                        <span className="text-sm font-medium">{building.style}</span>
                      </div>
                      {building.height && (
                        <div className="flex justify-between py-2 border-b">
                          <span className="text-sm text-gray-600">Height</span>
                          <span className="text-sm font-medium">{building.height}</span>
                        </div>
                      )}
                      {building.materials && building.materials.length > 0 && (
                        <div className="py-2 border-b">
                          <span className="text-sm text-gray-600 block mb-2">Materials</span>
                          <div className="flex flex-wrap gap-2">
                            {building.materials.map((material, index) => (
                              <Badge key={index} variant="outline">{material}</Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </ScrollArea>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}