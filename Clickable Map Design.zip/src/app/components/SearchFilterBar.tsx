import { Search, SlidersHorizontal, X } from "lucide-react";
import { useState } from "react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Label } from "./ui/label";
import { Slider } from "./ui/slider";
import { Checkbox } from "./ui/checkbox";
import { Badge } from "./ui/badge";
import { Building, architects, styles } from "../data/buildings";

interface SearchFilterBarProps {
  onSearch: (query: string) => void;
  onFilter: (filters: FilterOptions) => void;
  activeFilters: FilterOptions;
}

export interface FilterOptions {
  architects: string[];
  styles: string[];
  yearRange: [number, number];
}

export function SearchFilterBar({ onSearch, onFilter, activeFilters }: SearchFilterBarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  const [localFilters, setLocalFilters] = useState<FilterOptions>(activeFilters);

  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    onSearch(value);
  };

  const handleArchitectToggle = (architect: string) => {
    const newArchitects = localFilters.architects.includes(architect)
      ? localFilters.architects.filter(a => a !== architect)
      : [...localFilters.architects, architect];
    setLocalFilters({ ...localFilters, architects: newArchitects });
  };

  const handleStyleToggle = (style: string) => {
    const newStyles = localFilters.styles.includes(style)
      ? localFilters.styles.filter(s => s !== style)
      : [...localFilters.styles, style];
    setLocalFilters({ ...localFilters, styles: newStyles });
  };

  const handleYearRangeChange = (value: number[]) => {
    setLocalFilters({ ...localFilters, yearRange: [value[0], value[1]] });
  };

  const applyFilters = () => {
    onFilter(localFilters);
    setFilterOpen(false);
  };

  const clearFilters = () => {
    const defaultFilters: FilterOptions = {
      architects: [],
      styles: [],
      yearRange: [1800, 2026]
    };
    setLocalFilters(defaultFilters);
    onFilter(defaultFilters);
  };

  const activeFilterCount = 
    localFilters.architects.length + 
    localFilters.styles.length + 
    (localFilters.yearRange[0] !== 1800 || localFilters.yearRange[1] !== 2026 ? 1 : 0);

  return (
    <div className="absolute top-4 left-4 z-[1000] flex gap-2">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-500" />
        <Input
          type="text"
          placeholder="Search buildings..."
          value={searchQuery}
          onChange={(e) => handleSearchChange(e.target.value)}
          className="w-80 pl-10 bg-white shadow-lg border-gray-200"
        />
      </div>

      <Popover open={filterOpen} onOpenChange={setFilterOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" className="bg-white shadow-lg relative">
            <SlidersHorizontal className="size-4 mr-2" />
            Filters
            {activeFilterCount > 0 && (
              <Badge className="ml-2 px-1.5 min-w-5 h-5 flex items-center justify-center">
                {activeFilterCount}
              </Badge>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80 max-h-[500px] overflow-y-auto" align="start">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Filters</h4>
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                Clear all
              </Button>
            </div>

            <div className="space-y-3">
              <Label>Year Built</Label>
              <div className="space-y-2">
                <Slider
                  min={1800}
                  max={2026}
                  step={1}
                  value={localFilters.yearRange}
                  onValueChange={handleYearRangeChange}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-600">
                  <span>{localFilters.yearRange[0]}</span>
                  <span>{localFilters.yearRange[1]}</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <Label>Architect</Label>
              <div className="space-y-2">
                {architects.map((architect) => (
                  <div key={architect} className="flex items-center space-x-2">
                    <Checkbox
                      id={`architect-${architect}`}
                      checked={localFilters.architects.includes(architect)}
                      onCheckedChange={() => handleArchitectToggle(architect)}
                    />
                    <label
                      htmlFor={`architect-${architect}`}
                      className="text-sm cursor-pointer"
                    >
                      {architect}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <Label>Style</Label>
              <div className="space-y-2">
                {styles.map((style) => (
                  <div key={style} className="flex items-center space-x-2">
                    <Checkbox
                      id={`style-${style}`}
                      checked={localFilters.styles.includes(style)}
                      onCheckedChange={() => handleStyleToggle(style)}
                    />
                    <label
                      htmlFor={`style-${style}`}
                      className="text-sm cursor-pointer"
                    >
                      {style}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <Button onClick={applyFilters} className="w-full">
              Apply Filters
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
