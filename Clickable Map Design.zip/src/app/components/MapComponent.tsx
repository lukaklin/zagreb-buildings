import { useEffect, useRef } from "react";
import L from "leaflet";
import { Building } from "../data/buildings";
import "leaflet/dist/leaflet.css";

interface MapComponentProps {
  buildings: Building[];
  selectedBuilding: Building | null;
  onBuildingSelect: (building: Building) => void;
}

export function MapComponent({ buildings, selectedBuilding, onBuildingSelect }: MapComponentProps) {
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<Map<string, L.Marker>>(new Map());
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    // Initialize map centered on Zagreb
    const map = L.map(containerRef.current).setView([45.8150, 15.9819], 14);
    mapRef.current = map;

    // Add tile layer
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).addTo(map);

    // Cleanup
    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // Update markers when buildings change
  useEffect(() => {
    if (!mapRef.current) return;

    const map = mapRef.current;

    // Clear existing markers
    markersRef.current.forEach((marker) => marker.remove());
    markersRef.current.clear();

    // Create default icon
    const defaultIcon = L.icon({
      iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
      iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
      shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      shadowSize: [41, 41],
    });

    const activeIcon = L.icon({
      iconUrl: "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png",
      shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      shadowSize: [41, 41],
    });

    // Add markers for each building
    buildings.forEach((building) => {
      const isSelected = selectedBuilding?.id === building.id;
      const marker = L.marker([building.location.lat, building.location.lng], {
        icon: isSelected ? activeIcon : defaultIcon,
      }).addTo(map);

      marker.bindPopup(`
        <div style="font-size: 14px;">
          <p style="font-weight: 500; margin: 0 0 4px 0;">${building.name}</p>
          <p style="font-size: 12px; color: #666; margin: 0;">${building.architect}</p>
        </div>
      `);

      marker.on("click", () => {
        onBuildingSelect(building);
      });

      markersRef.current.set(building.id, marker);
    });
  }, [buildings, selectedBuilding, onBuildingSelect]);

  // Fly to selected building
  useEffect(() => {
    if (!mapRef.current || !selectedBuilding) return;

    mapRef.current.flyTo(
      [selectedBuilding.location.lat, selectedBuilding.location.lng],
      15,
      { duration: 1 }
    );
  }, [selectedBuilding]);

  return <div ref={containerRef} className="size-full" />;
}