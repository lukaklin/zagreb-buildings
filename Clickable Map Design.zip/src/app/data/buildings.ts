export interface Building {
  id: string;
  name: string;
  architect: string;
  yearBuilt: number;
  age: number;
  style: string;
  description: string;
  location: {
    lat: number;
    lng: number;
  };
  mainImage: string;
  gallery: string[];
  height?: string;
  materials?: string[];
}

export const buildings: Building[] = [
  {
    id: "1",
    name: "Zagreb Cathedral",
    architect: "Hermann Bollé",
    yearBuilt: 1880,
    age: 146,
    style: "Neo-Gothic",
    description: "The iconic Zagreb Cathedral, officially the Cathedral of the Assumption of the Blessed Virgin Mary, is a Roman Catholic institution and the tallest building in Croatia. The cathedral was rebuilt and restored by Hermann Bollé after the 1880 earthquake. Its distinctive twin neo-Gothic spires dominate the city skyline and are visible from many parts of Zagreb.",
    location: { lat: 45.8144, lng: 15.9795 },
    mainImage: "neo gothic cathedral twin spires",
    gallery: [
      "cathedral interior gothic",
      "church stained glass windows",
      "neo gothic architecture details",
      "cathedral altar"
    ],
    height: "108m",
    materials: ["Stone", "Brick", "Wood"]
  },
  {
    id: "2",
    name: "Croatian National Theatre",
    architect: "Ferdinand Fellner & Hermann Helmer",
    yearBuilt: 1895,
    age: 131,
    style: "Neo-Baroque",
    description: "The Croatian National Theatre in Zagreb is a stunning example of late 19th-century neo-Baroque architecture. Designed by the famous Viennese architectural duo Fellner & Helmer, the building features an ornate yellow facade, elaborate interior decorations, and a magnificent chandelier. It serves as the primary venue for opera, ballet, and drama performances in Croatia.",
    location: { lat: 45.8103, lng: 15.9675 },
    mainImage: "neo baroque theatre building yellow",
    gallery: [
      "theatre interior ornate",
      "baroque architecture facade",
      "grand theatre hall",
      "classical architecture columns"
    ],
    height: "28m",
    materials: ["Stone", "Marble", "Gold Leaf"]
  },
  {
    id: "3",
    name: "Cibona Tower",
    architect: "Marijan Haberle",
    yearBuilt: 1987,
    age: 39,
    style: "Modernist",
    description: "Cibona Tower is a distinctive modernist skyscraper and sports arena complex. The building features a unique cylindrical design and served as one of Zagreb's most recognizable landmarks of socialist-era modern architecture. The tower originally housed the Cibona basketball team and includes residential and commercial spaces. Its brutalist-modernist aesthetic represents the architectural ambitions of 1980s Yugoslavia.",
    location: { lat: 45.8050, lng: 15.9580 },
    mainImage: "modernist tower building",
    gallery: [
      "brutalist architecture",
      "modern concrete building",
      "cylindrical tower",
      "socialist architecture"
    ],
    height: "92m",
    materials: ["Reinforced Concrete", "Glass", "Steel"]
  },
  {
    id: "4",
    name: "Art Pavilion",
    architect: "Fellner & Helmer",
    yearBuilt: 1898,
    age: 128,
    style: "Secession",
    description: "The Art Pavilion is Zagreb's first exhibition hall and a premier example of Viennese Secession style architecture. Originally designed for the 1896 Millennium Exhibition in Budapest, it was relocated to Zagreb and reconstructed. The building features a striking yellow facade with elegant Art Nouveau details, ornamental metalwork, and a glass dome. It continues to host important art exhibitions and cultural events.",
    location: { lat: 45.8117, lng: 15.9739 },
    mainImage: "art nouveau pavilion yellow",
    gallery: [
      "secession architecture",
      "art nouveau building details",
      "exhibition hall interior",
      "ornamental metalwork"
    ],
    height: "15m",
    materials: ["Steel Frame", "Glass", "Decorative Plaster"]
  },
  {
    id: "5",
    name: "Lotrščak Tower",
    architect: "Unknown (Medieval builders)",
    yearBuilt: 1266,
    age: 760,
    style: "Medieval Romanesque",
    description: "Lotrščak Tower is one of the oldest buildings in Zagreb, built in the 13th century to protect the southern gate of Gradec. The Romanesque tower stands 30 meters tall and has walls one meter thick. Since 1877, the Grič cannon has been fired from the tower every day at noon, a tradition that continues today. The tower offers panoramic views of Zagreb's historic center.",
    location: { lat: 45.8153, lng: 15.9733 },
    mainImage: "medieval stone tower",
    gallery: [
      "romanesque tower",
      "medieval architecture stone",
      "historic fortress",
      "old city walls"
    ],
    height: "30m",
    materials: ["Stone", "Brick"]
  },
  {
    id: "6",
    name: "Museum of Contemporary Art",
    architect: "Igor Franić",
    yearBuilt: 2009,
    age: 17,
    style: "Contemporary",
    description: "The Museum of Contemporary Art is a striking example of 21st-century museum architecture. Designed by Croatian architect Igor Franić, the building features clean geometric lines, extensive use of glass and concrete, and spacious galleries flooded with natural light. The museum's modern design creates a perfect backdrop for contemporary art exhibitions and has become a landmark in Zagreb's Novi Zagreb district.",
    location: { lat: 45.8006, lng: 15.9617 },
    mainImage: "contemporary museum glass building",
    gallery: [
      "modern museum architecture",
      "contemporary building design",
      "glass facade building",
      "minimalist architecture"
    ],
    height: "22m",
    materials: ["Concrete", "Glass", "Steel"]
  },
  {
    id: "7",
    name: "Esplanade Zagreb Hotel",
    architect: "Josip Vancaš & Drago Galić",
    yearBuilt: 1925,
    age: 101,
    style: "Art Deco",
    description: "The Esplanade is Zagreb's most luxurious hotel, built in 1925 to accommodate passengers of the Orient Express. The building showcases elegant Art Deco architecture with a symmetrical facade, decorative elements, and luxurious interiors. The hotel features the famous Zeppelin Hall restaurant, marble staircases, crystal chandeliers, and has hosted numerous celebrities and dignitaries throughout its history.",
    location: { lat: 45.8056, lng: 15.9817 },
    mainImage: "art deco hotel building",
    gallery: [
      "luxury hotel interior",
      "art deco architecture 1920s",
      "elegant hotel lobby",
      "historic hotel facade"
    ],
    height: "35m",
    materials: ["Stone", "Marble", "Bronze"]
  },
  {
    id: "8",
    name: "Vatroslav Lisinski Concert Hall",
    architect: "Marijan Haberle",
    yearBuilt: 1973,
    age: 53,
    style: "Brutalist",
    description: "The Vatroslav Lisinski Concert Hall is Croatia's largest concert venue and a prominent example of brutalist architecture. Designed by Marijan Haberle, the building features exposed concrete, geometric forms, and excellent acoustics. The main hall seats 1,841 people and hosts performances by the Zagreb Philharmonic Orchestra. The building's raw concrete aesthetic exemplifies the architectural philosophy of socialist Yugoslavia.",
    location: { lat: 45.8064, lng: 15.9669 },
    mainImage: "brutalist concert hall",
    gallery: [
      "brutalist architecture concrete",
      "concert hall interior",
      "modernist building",
      "geometric architecture"
    ],
    height: "38m",
    materials: ["Exposed Concrete", "Glass", "Wood Paneling"]
  },
  {
    id: "9",
    name: "Strossmayer Gallery of Old Masters",
    architect: "Friedrich von Schmidt",
    yearBuilt: 1884,
    age: 142,
    style: "Neo-Renaissance",
    description: "The Strossmayer Gallery houses the Croatian Academy of Sciences and Arts collection of Old Masters paintings. Designed by the renowned architect Friedrich von Schmidt in the neo-Renaissance style, the building features elegant arches, ornate facades, and classical proportions. The interior includes a grand atrium with arcades and a beautiful courtyard, creating an ideal setting for displaying art.",
    location: { lat: 45.8120, lng: 15.9755 },
    mainImage: "neo renaissance palace building",
    gallery: [
      "renaissance architecture facade",
      "classical courtyard arcades",
      "ornate palace interior",
      "historical building details"
    ],
    height: "24m",
    materials: ["Stone", "Marble", "Stucco"]
  },
  {
    id: "10",
    name: "Mimara Museum",
    architect: "Ludwig Zettl & Hinko Bauer",
    yearBuilt: 1895,
    age: 131,
    style: "Neo-Renaissance",
    description: "Originally built as a German gymnasium school, this neo-Renaissance building now houses the Mimara Museum's extensive art collection. The building features classical symmetry, ornate window frames, and decorative elements typical of late 19th-century Vienna's influence on Zagreb's architecture. The museum underwent renovation in the 1980s to accommodate its world-class collection of art spanning various periods and cultures.",
    location: { lat: 45.8089, lng: 15.9719 },
    mainImage: "neo renaissance museum building",
    gallery: [
      "classical architecture school",
      "renaissance revival building",
      "ornate building facade",
      "museum exterior"
    ],
    height: "26m",
    materials: ["Brick", "Stone", "Decorative Plaster"]
  }
];

export const architects = Array.from(new Set(buildings.map(b => b.architect))).sort();
export const styles = Array.from(new Set(buildings.map(b => b.style))).sort();
